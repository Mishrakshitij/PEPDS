The structure of the entire setup is as follows:

______________/RL
|              |___ models 		# Directory to save fine-tuned Models
|              |___ dataset		# Directory to load annotated dataset form.
|		   |___ rlmain.py		# script for fine-tuning ARDM model.
|              |___ rlinference.py 	# script to interact with the fine-tuned model.
|
|_____________/ARDM
		   |___models		# Directory to store the pre-trained ARDM model to use for RL fine-tuning
		   |___ data		# Directory to load original P4G dataset from.
		   |___ interact.py	 # script to interact with pre trained ARDM model.

****REQUIREMENTS****
1. numpy: version '1.21.2'
2. pandas: version '1.3.4'
3. transformers: version '4.11.3'
4. tqdm: version: version '4.62.3'
5. torch: version '1.10.0'


****FINE-TUNING RL MODEL****

1. Go to the RL folder. 
2. Provide all the arguments in the rlmain.py file.
3. Go to terminal window and enter python rlmain.py to start the rl fine-tuning.

Args:
modelname:str, 'the desired modelname',
csvfile:str, the csv file to load the persuasion dataset from
emo_classifier_filename:str, path to the saved emotional classifier
device:str, Default='cuda'
n_epochs:int, Default=1
batch_size:int, Default=1
mini_batch=int, Default=1
train_single_model:bool, Whether to fine-tune both persuader and persuadee during RL fine tuning, Default=True
single_model_to_train:str, Which model of train 'persuader' or 'persuadee', Default:'persuader',
num_candidates:int, number of candidates to generate at a turn for the persuader, Default=2
recompute_log_prob:bool, Whether to recompute the log probability of the generated candidates, Default= True
average_sent_loss:bool, Whether to average the loss the over the entire sentence for the generated candidates, Default=True
max_candidate_length:int, Maximum length of generated candidates, Default=50
human_reward:int, Default=10
beta:float, Default=2
beta2:float, Default=2
beta3:float, Default=2
top_p:float, The probability sum threshold to consider when generating tokens for the candidates,  Default=0.9
temperature:float, The temprate value when calculating the loss, Default=0.8
use_recent_past:bool, Whether to consider 
warmup_steps:int, number of warm up step to be given to the scheduler, Default=10
print_every:int, number of steps before printing the loss Default=1
evaluate_every:int, Iterations before evaluation, Default=1
learning_rate:float, Default=2e-05
epsilon:float, Default=0.2
loadARDM:bool, Whether to load the ARDM model for fine tuning, Default=True
ARDMFilename:str, path to the saved ARDM model
pad_token_id:str, Default=None
seedvalue:int, Default=10
use_emo_classifier:bool whether to use emotional classifier, Default=True
use_persuasion_classifier:bool whether to use persuasion classifier, Default=True
use_politeness_classifier:bool whether to use politeness classifier, Default=True
per_classifier_filename:str,  path to the saved persuasion classifier
per_num_labels:int, number of persuasion labels, Default=11
emo_num_labels:int, number of emotion labels, Default=23
pol_num_labels:int, number of politeness labels, Default=3
use_bleu:bool, Whether to use bleu score as reward, Default=False
use_jaccard:bool, Whether to use jaccard as reward, Default=True
use_cosine:bool, Whether to use cosine as reward, Default=False
use_meteor:bool, Whether to use meteor as reward, Default=True
gamma1:float, weight for the jaccard reward, Default=0.1
gamma2:float, weight for the meteor reward, Default=0.1
gamma3:float, weight for the emotion reward, Default=0.2
gamma4:float, weight for the persuasion reward, Default=0.2
gamma5:float, weight for the politeness reward, Default=0.3	
get_num_strategy:bool, Whether to evaluate the model for number of persuasion strategy, set to True only during evaluation, Default=False
load_model_for_validation:str, path to the saved fine tuned model to load for validation, the get_num_strategy should also be set to True, Default=None




