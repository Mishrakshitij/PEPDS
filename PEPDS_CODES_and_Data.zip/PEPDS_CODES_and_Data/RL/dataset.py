import torch
from torch.utils.data import DataLoader, Dataset
import pdb

class PersuadeDataset(Dataset):
    def __init__(self, data, tokenizer, use_emotion_labels=False, use_persuasion_labels=False, use_politeness_labels=False):
        self.data = data
        self.use_emotion_labels = use_emotion_labels
        self.use_persuasion_labels = use_persuasion_labels
        self.use_politeness_labels = use_politeness_labels
        self.tokenizer = tokenizer
        self.tokenizer.max_len = 1500
        self.turn_ending = [628, 198]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        #dial_tokens = [self.tokenizer.encode(item) + self.turn_ending for item in self.data[index]]
        if self.use_emotion_labels and self.use_persuasion_labels and not self.use_politeness_labels:
            # EMOTION AND PERSUASION ONLY
            dial_tokens = [self.tokenizer.encode(item[0]) + self.turn_ending for item in self.data[index]]
            # 32 is the encoding for "A:"
            role_ids = [0 if item[0] == 32 else 1 for item in dial_tokens]
            emo_labels = [item[1] for item in self.data[index]]
            persuasion_labels = [item[2] for item in self.data[index]]
            return role_ids, dial_tokens, emo_labels, persuasion_labels
        elif self.use_emotion_labels and self.use_persuasion_labels and self.use_politeness_labels:
            # ALL LABELS
            dial_tokens = [self.tokenizer.encode(item[0]) + self.turn_ending for item in self.data[index]]
            # 32 is the encoding for "A:"
            role_ids = [0 if item[0] == 32 else 1 for item in dial_tokens]
            emo_labels = [item[1] for item in self.data[index]]
            persuasion_labels = [item[2] for item in self.data[index]]
            politeness_labels = [item[3] for item in self.data[index]]
            return role_ids, dial_tokens, emo_labels, persuasion_labels, politeness_labels
        elif self.use_emotion_labels and not self.use_persuasion_labels and not self.use_politeness_labels:
            # EMOTION ONLY
            dial_tokens = [self.tokenizer.encode(item[0]) + self.turn_ending for item in self.data[index]]
            # 32 is the encoding for "A:"
            role_ids = [0 if item[0] == 32 else 1 for item in dial_tokens]
            emo_labels = [item[1] for item in self.data[index]]
            return role_ids, dial_tokens, emo_labels
        elif not self.use_emotion_labels and self.use_persuasion_labels and not self.use_politeness_labels:
            # PERSUASION ONLY
            dial_tokens = [self.tokenizer.encode(item[0]) + self.turn_ending for item in self.data[index]]
            # 32 is the encoding for "A:"
            role_ids = [0 if item[0] == 32 else 1 for item in dial_tokens]
            persuasion_labels = [item[1] for item in self.data[index]]
            return role_ids, dial_tokens, persuasion_labels
        elif self.use_emotion_labels and not self.use_persuasion_labels and self.use_politeness_labels:
            # EMOTION AND POLITENESS ONLY
            dial_tokens = [self.tokenizer.encode(item[0]) + self.turn_ending for item in self.data[index]]
            role_ids = [0 if item[0] == 32 else 1 for item in dial_tokens]
            emo_labels = [item[1] for item in self.data[index]]
            politeness_labels = [item[2] for item in self.data[index]]
            return role_ids, dial_tokens, emo_labels, politeness_labels
        elif not self.use_emotion_labels and self.use_persuasion_labels and self.use_politeness_labels:
            # PERSUASION AND POLITENESS ONLY
            dial_tokens = [self.tokenizer.encode(item[0]) + self.turn_ending for item in self.data[index]]
            role_ids = [0 if item[0] == 32 else 1 for item in dial_tokens]
            persuasion_labels = [item[1] for item in self.data[index]]
            politeness_labels = [item[2] for item in self.data[index]]
            return role_ids, dial_tokens, persuasion_labels, politeness_labels
        elif not self.use_emotion_labels and not self.use_persuasion_labels and self.use_politeness_labels:
            # POLITENESS ONLY
            dial_tokens = [self.tokenizer.encode(item[0]) + self.turn_ending for item in self.data[index]]
            role_ids = [0 if item[0] == 32 else 1 for item in dial_tokens]
            politeness_labels = [item[1] for item in self.data[index]]
            return role_ids, dial_tokens, politeness_labels
        else:
            dial_tokens = [self.tokenizer.encode(item) + self.turn_ending for item in self.data[index]]
            # 32 is the encoding for "A:"
            role_ids = [0 if item[0] == 32 else 1 for item in dial_tokens]
            return role_ids, dial_tokens


    def collate(self, unpacked_data):
        return unpacked_data

    def get_turn_ending(self):
        return self.turn_ending
